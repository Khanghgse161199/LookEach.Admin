(function ($) {
    "use strict"; $(".others-option .search-btn").on("click", function () { $(".search-overlay").toggleClass("search-overlay-active"); }); $(".search-overlay-close").on("click", function () { $(".search-overlay").removeClass("search-overlay-active"); }); $(".header-top-others-option .search-btn").on("click", function () { $(".search-overlay").toggleClass("search-overlay-active"); }); $('.mean-menu').meanmenu({ meanScreenWidth: "991" }); $(window).on('scroll', function () {
        if ($(this).scrollTop() > 130) { $('.header-sticky').addClass("is-sticky"); }
        else { $('.header-sticky').removeClass("is-sticky"); }
    }); var c, currentScrollTop = 0, navbar = $('.header-sticky'); $(window).scroll(function () {
        var a = $(window).scrollTop(); var b = navbar.height(); currentScrollTop = a; if (c < currentScrollTop && a > b + b) { navbar.addClass("scrollUp"); } else if (c > currentScrollTop && !(a <= b)) { navbar.removeClass("scrollUp"); }
        c = currentScrollTop;
    }); $('.home-slides').owlCarousel({ loop: true, nav: true, dots: true, autoplayHoverPause: true, autoplay: true, smartSpeed: 500, autoHeight: true, items: 1, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], }); $(".home-slides").on("translate.owl.carousel", function () { $(".main-banner-content .sub-title").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); $(".main-banner-content h1").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); $(".main-banner-content p").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); $(".main-banner-content .btn-box").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); }); $(".home-slides").on("translated.owl.carousel", function () { $(".main-banner-content .sub-title").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); $(".main-banner-content h1").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); $(".main-banner-content p").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); $(".main-banner-content .btn-box").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); }); $('.home-slides-two').owlCarousel({ loop: true, nav: true, dots: false, autoplayHoverPause: true, autoplay: true, autoHeight: true, animateOut: 'animate__animated animate__slideOutUp', items: 1, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], }); $('.home-slides-three').owlCarousel({ loop: true, nav: false, dots: true, autoplayHoverPause: true, items: 1, smartSpeed: 750, autoplay: true, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], }); $(".home-slides-three").on("translate.owl.carousel", function () { $(".main-banner-content .sub-title").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); $(".main-banner-content h1").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); $(".main-banner-content p").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); $(".main-banner-content .btn-box").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); $(".banner-image img").removeClass("animate__animated animate__fadeInUp").css("opacity", "0"); $(".banner-image .circle").removeClass("animate__animated animate__zoomIn").css("opacity", "0"); }); $(".home-slides-three").on("translated.owl.carousel", function () { $(".main-banner-content .sub-title").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); $(".main-banner-content h1").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); $(".main-banner-content p").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); $(".main-banner-content .btn-box").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); $(".banner-image img").addClass("animate__animated animate__fadeInUp").css("opacity", "1"); $(".banner-image .circle").addClass("animate__animated animate__zoomIn").css("opacity", "1"); }); $(function () { $('[data-bs-toggle="tooltip"]').tooltip(); }); $('.facility-slides').owlCarousel({ loop: true, nav: true, dots: false, autoplayHoverPause: true, autoplay: true, margin: 30, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], responsive: { 0: { items: 1, }, 576: { items: 2, }, 768: { items: 3, }, 1200: { items: 4, } } }); $('.products-slides').owlCarousel({ loop: true, nav: true, dots: false, autoplayHoverPause: true, autoplay: true, margin: 30, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], responsive: { 0: { items: 1, }, 576: { items: 2, }, 768: { items: 2, }, 1200: { items: 3, } } }); $('.instagram-slides').owlCarousel({ loop: true, nav: false, dots: false, autoplayHoverPause: true, autoplay: true, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], responsive: { 0: { items: 1, }, 576: { items: 2, }, 768: { items: 3, }, 1200: { items: 6, } } }); $('.partner-slides').owlCarousel({ loop: true, nav: false, dots: false, autoplayHoverPause: true, autoplay: true, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], responsive: { 0: { items: 2, }, 576: { items: 4, }, 768: { items: 4, }, 1200: { items: 7, } } }); $('.offer-products-slides').owlCarousel({ loop: true, nav: false, dots: true, autoplayHoverPause: true, autoplay: true, animateOut: 'fadeOut', mouseDrag: false, items: 1, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], }); $('.brand-slides').owlCarousel({ loop: true, nav: false, dots: false, autoplayHoverPause: true, autoplay: true, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], responsive: { 0: { items: 2, }, 576: { items: 3, }, 768: { items: 4, }, 1200: { items: 7, } } }); $(".js-range-of-price").ionRangeSlider({ type: "double", drag_interval: true, min_interval: null, max_interval: null, }); $('.input-counter').each(function () {
        var spinner = jQuery(this), input = spinner.find('input[type="text"]'), btnUp = spinner.find('.plus-btn'), btnDown = spinner.find('.minus-btn'), min = input.attr('min'), max = input.attr('max'); btnUp.on('click', function () {
            var oldValue = parseFloat(input.val()); if (oldValue >= max) { var newVal = oldValue; } else { var newVal = oldValue + 1; }
            spinner.find("input").val(newVal); spinner.find("input").trigger("change");
        }); btnDown.on('click', function () {
            var oldValue = parseFloat(input.val()); if (oldValue <= min) { var newVal = oldValue; } else { var newVal = oldValue - 1; }
            spinner.find("input").val(newVal); spinner.find("input").trigger("change");
        });
    }); $('.testimonials-slides').owlCarousel({ loop: true, nav: false, dots: true, margin: 30, autoplayHoverPause: true, autoplay: true, center: true, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], responsive: { 0: { items: 1, }, 576: { items: 2, }, 768: { items: 2, }, 1200: { items: 3, } } }); (function ($) { $('.tab ul.tabs').addClass('active').find('> li:eq(0)').addClass('current'); $('.tab ul.tabs li a').on('click', function (g) { var tab = $(this).closest('.tab'), index = $(this).closest('li').index(); tab.find('ul.tabs > li').removeClass('current'); $(this).closest('li').addClass('current'); tab.find('.tab-content').find('div.tabs-item').not('div.tabs-item:eq(' + index + ')').slideUp(); tab.find('.tab-content').find('div.tabs-item:eq(' + index + ')').slideDown(); g.preventDefault(); }); })(jQuery); $(function () { $('.accordion').find('.accordion-title').on('click', function () { $(this).toggleClass('active'); $(this).next().slideToggle('fast'); $('.accordion-content').not($(this).next()).slideUp('fast'); $('.accordion-title').not($(this)).removeClass('active'); }); }); $(function () {
        $(".icon-view-one").on("click", function (e) {
            e.preventDefault(); document.getElementById("products-collections-filter").classList.add('products-col-one')
            document.getElementById("products-collections-filter").classList.remove('products-col-two', 'products-col-three', 'products-col-four', 'products-row-view');
        }); $(".icon-view-two").on("click", function (e) {
            e.preventDefault(); document.getElementById("products-collections-filter").classList.add('products-col-two')
            document.getElementById("products-collections-filter").classList.remove('products-col-one', 'products-col-three', 'products-col-four', 'products-row-view');
        }); $(".icon-view-three").on("click", function (e) {
            e.preventDefault(); document.getElementById("products-collections-filter").classList.add('products-col-three')
            document.getElementById("products-collections-filter").classList.remove('products-col-one', 'products-col-two', 'products-col-four', 'products-row-view');
        }); $(".icon-view-four").on("click", function (e) {
            e.preventDefault(); document.getElementById("products-collections-filter").classList.add('products-col-four')
            document.getElementById("products-collections-filter").classList.remove('products-col-one', 'products-col-two', 'products-col-three', 'products-row-view');
        }); $(".view-grid-switch").on("click", function (e) {
            e.preventDefault(); document.getElementById("products-collections-filter").classList.add('products-row-view')
            document.getElementById("products-collections-filter").classList.remove('products-col-one', 'products-col-two', 'products-col-three', 'products-col-four');
        }); $(".icon-view-six").on("click", function (e) {
            e.preventDefault(); document.getElementById("products-collections-filter").classList.add('products-col-six')
            document.getElementById("products-collections-filter").classList.remove('products-col-one', 'products-col-two', 'products-col-three', 'products-col-four', 'products-row-view');
        });
    }); $('.products-filter-options .view-column a').on('click', function () { $('.view-column a').removeClass("active"); $(this).addClass("active"); }); $('select').niceSelect(); $('.blog-slides').owlCarousel({ loop: true, nav: false, dots: true, autoplayHoverPause: true, autoplay: true, margin: 30, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], responsive: { 0: { items: 1, }, 768: { items: 2, }, 1200: { items: 3, } } }); $(".newsletter-form").validator().on("submit", function (event) { if (event.isDefaultPrevented()) { formErrorSub(); submitMSGSub(false, "Please enter your email correctly."); } else { event.preventDefault(); } }); function callbackFunction(resp) {
        if (resp.result === "success") { formSuccessSub(); }
        else { formErrorSub(); }
    }
    function formSuccessSub() { $(".newsletter-form")[0].reset(); submitMSGSub(true, "Thank you for subscribing!"); setTimeout(function () { $("#validator-newsletter").addClass('hide'); }, 4000) }
    function formErrorSub() { $(".newsletter-form").addClass("animate__animated animate__shake"); setTimeout(function () { $(".newsletter-form").removeClass("animate__animated animate__shake"); }, 1000) }
    function submitMSGSub(valid, msg) {
        if (valid) { var msgClasses = "validation-success"; } else { var msgClasses = "validation-danger"; }
        $("#validator-newsletter").removeClass().addClass(msgClasses).text(msg);
    }
    $(".newsletter-form").ajaxChimp({ url: "https://envytheme.us20.list-manage.com/subscribe/post?u=60e1ffe2e8a68ce1204cd39a5&amp;id=42d6d188d9", callback: callbackFunction }); $('.popup-btn').magnificPopup({ type: 'image', removalDelay: 300, gallery: { enabled: true }, callbacks: { beforeOpen: function () { this.st.image.markup = this.st.image.markup.replace('mfp-figure', 'mfp-figure animated ' + this.st.el.attr('data-effect')); } }, }); var $grid = $('.gallery-items, .blog-items, .lookbook-items').isotope({ itemSelector: '.grid-item', percentPosition: true, masonry: { columnWidth: '.grid-item' } }); $('.article-image-slides').owlCarousel({ loop: true, nav: true, dots: false, autoplayHoverPause: true, autoplay: true, animateOut: 'fadeOut', items: 1, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], }); $('.products-details-desc-sticky').stickySidebar({ topSpacing: 110, bottomSpacing: 110 }); $('.products-details-image-slides').slick({ dots: true, speed: 500, fade: false, slide: 'li', slidesToShow: 1, autoplay: true, autoplaySpeed: 4000, prevArrow: false, nextArrow: false, responsive: [{ breakpoint: 800, settings: { arrows: false, centerMode: false, centerPadding: '40px', variableWidth: false, slidesToShow: 1, dots: true }, breakpoint: 1200, settings: { arrows: false, centerMode: false, centerPadding: '40px', variableWidth: false, slidesToShow: 1, dots: true } }], customPaging: function (slider, i) { return '<button class="tab">' + $('.slick-thumbs li:nth-child(' + (i + 1) + ')').html() + '</button>'; } }); $('.products-details-image-slider').owlCarousel({ loop: true, nav: true, dots: false, autoplayHoverPause: true, autoplay: true, margin: 30, navText: ["<i class='flaticon-left'></i>", "<i class='flaticon-right-arrow'></i>"], responsive: { 0: { items: 1, }, 576: { items: 2, }, 768: { items: 2, }, 1200: { items: 3, } } }); function makeTimer() {
        var endTime = new Date("June 5, 2024 17:00:00 PDT"); var endTime = (Date.parse(endTime)) / 1000; var now = new Date(); var now = (Date.parse(now) / 1000); var timeLeft = endTime - now; var days = Math.floor(timeLeft / 86400); var hours = Math.floor((timeLeft - (days * 86400)) / 3600); var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600)) / 60); var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60))); if (hours < "10") { hours = "0" + hours; }
        if (minutes < "10") { minutes = "0" + minutes; }
        if (seconds < "10") { seconds = "0" + seconds; }
        $("#days").html(days + "<span>Ngày</span>"); $("#hours").html(hours + "<span>Giờ</span>"); $("#minutes").html(minutes + "<span>Phút</span>"); $("#seconds").html(seconds + "<span>Giây</span>");
    }
    setInterval(function () { makeTimer(); }, 0); $(function () { $(window).on('scroll', function () { var scrolled = $(window).scrollTop(); if (scrolled > 300) $('.go-top').addClass('active'); if (scrolled < 300) $('.go-top').removeClass('active'); }); $('.go-top').on('click', function () { $("html, body").animate({ scrollTop: "0" }, 500); }); }); $(window).on('load', function () { if ($(".wow").length) { var wow = new WOW({ boxClass: 'wow', animateClass: 'animated', offset: 20, mobile: true, live: true, }); wow.init(); } }); $('body').append("<div></div>"); $('body').append("<div class='switch-box'></div>");
}(jQuery));

(function ($) {
    "use strict";

    // Initiate the wowjs
    new WOW().init();

    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 40) {
            $('.navbar').addClass('sticky-top');
        } else {
            $('.navbar').removeClass('sticky-top');
        }
    });

    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1500,
        margin: 45,
        dots: true,
        loop: true,
        center: true,
        responsive: {
            0: {
                items: 1
            },
            576: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 3
            }
        }
    });

})(jQuery);

