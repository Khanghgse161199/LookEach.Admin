const n=()=>n=>n;export{n};
