class e{static register(e,t){window.Blazor.registerCustomEventType(e,{createEventArgs:t})}}export{e as C};
